<?php
if(isset($_POST['btn_save'])){
    include "db_conn.php";
    $first_name = $_POST['first_name'];
    $mid_name = $_POST['mid_name'];
    $last_name = $_POST['last_name'];
    $suffix = $_POST['suffix'];
    $sex = $_POST['sex'];
    $date_of_birth = $_POST['date_of_birth'];
    $civil_status = $_POST['civil_status'];
    $voter_status = $_POST['voter_status'];
    $house_number = $_POST['house_number'];
    $street = $_POST['street'];
    $purok = $_POST['purok'];
    $occ = $_POST['occ'];
    $citi = $_POST['citi'];
    $health = $_POST['health'];
    $phone_number = $_POST['phone_number'];
    $tel_number = $_POST['tel_number'];
    $email = $_POST['email'];
        
                    $sql = "INSERT INTO `residents`
                    (
                    `first_name`, 
                    `mid_name`, 
                    `last_name`, 
                    `suffix`, 
                    `sex`, 
                    `date_of_birth`, 
                    `house_number`, 
                    `street`, 
                    `purok`, 
                    `occupation`, 
                    `citizenship`, 
                    `health_status`, 
                    `civil_status`, 
                    `voter_status`, 
                    `phone_number`, 
                    `tel_number`, 
                    `email`) 
                    VALUES (
                    '$first_name',
                    '$mid_name',
                    '$last_name',
                    '$suffix',
                    '$sex',
                    '$date_of_birth',
                    '$house_number',
                    '$street',
                    '$purok',
                    '$occ',
                    '$citi',
                    '$health',
                    '$civil_status',
                    '$voter_status',
                    '$phone_number',
                    '$tel_number',
                    '$email'
                    )";
    
                    mysqli_query($conn,$sql);
                    header("location:index.php");
                    
                    }
?>